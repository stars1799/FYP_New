library(shiny)
library(tidymodels)
library(reactlog)

# Define UI for application
ui <- fluidPage(
  titlePanel("Desire Line Calculator"),
  sidebarLayout(
    sidebarPanel(
      selectInput("input1", "Throughout the various times of the day, do you tend to use different routes when navigating through your residential estate?", choices = c("Yes", "No")),
      selectInput("input2", "Do well-lit walkways affect your choice of route when navigating through your residential estate?" , choices = c("Yes", "No")),
      selectInput("input3", "Does terrain elevation (e.g. hills/big slopes) affect your choice of route when navigating through your residential estate?", choices = c("Yes", "No")),
      selectInput("input4", "Does convenience affect your choice of route when navigating through your residential estate?", choices = c("Yes", "No")),
      numericInput("input5", "What is your age?", value = '25'),
      selectInput("input6", "What type of housing do you currently live in Singapore?", choices = c("HDB", "Condominium","Landed Property")),
      selectInput("input7", "How often do you walk in your immediate neighbourhood?",choices = c("Always", "Frequently","Sometimes","Seldom","Never")),
      actionButton("predictButton","Predict")
    ),
    mainPanel(
      textOutput("predictionText"),
      textOutput("confidenceText")
    )
  )
)

# Define server logic
server <- function(input, output, session) {
  # Initialize flag to track if data has been loaded
  is_loaded <- reactiveVal(FALSE)
  
  # Initialize trained model
  trained_model <- reactiveVal(NULL)
  
  # Function to load data and train model
  load_and_train <- function() {
    file_path <- "LR_Data.csv"
    df <- read.csv(file_path, header = TRUE)[,-1]
    y <- df[[ncol(df)]]
    X <- df[, -ncol(df)]
    fit <- logistic_reg(mixture = double(1), penalty = double(1)) %>%
      set_engine("glmnet") %>%
      set_mode("classification") %>%
      fit(as.factor(y) ~ ., data = X)
    trained_model(fit)
    is_loaded(TRUE)
  }
  
  # Make predictions
  observeEvent(input$predictButton, {
    # Load data and train model if not already loaded
    if (!is_loaded()) {
      load_and_train()
    }
    
    # Use new_data for predictions
    new_data <- data.frame(
      input1 = input$input1,
      input2 = input$input2,
      input3 = input$input3,
      input4 = input$input4,
      input5 = input$input5,
      input6 = input$input6,
      input7 = input$input7,
      fixed_var1 = 0.948905,
      fixed_var2 = 0.948905,
      fixed_var3 = 0.649635,
      stringsAsFactors = TRUE
    )
    colnames(new_data) <- c("Throughout.the.various.times.of.the.day..do.you.tend.to.use.different.routes.when.navigating.through.your.residential.estate.", 
                            "Do.well.lit.walkways.affect.your.choice.of.route.when.navigating.through.your.residential.estate.",
                            "Does.terrain.elevation..e.g..hills.big.slopes..affect.your.choice.of.route.when.navigating.through.your.residential.estate.",
                            "Does.convenience.affect.your.choice.of.route.when.navigating.through.your.residential.estate.", 
                            "What.is.your.age.", 
                            "What.type.of.housing.do.you.currently.live.in.Singapore.", 
                            "How.often.do.you.walk.in.your.immediate.neighbourhood.", 
                            "Q32_Encoded", "Q33_Encoded", "Q34_Encoded")
    
    # Make predictions
    if (!is.null(trained_model())) {
      prediction <- predict(trained_model(), new_data = new_data, type = "class")
      
      if (prediction == 1) {
        confidence <- predict(trained_model(), new_data = new_data, type = "prob")[, 2]  # Probability of class 1
        confidence_text <- paste("Confidence (Likely to walk on desire path):", round(confidence * 100, 2), "%")
      } else {
        confidence <- predict(trained_model(), new_data = new_data, type = "prob")[, 1]  # Probability of class 0
        confidence_text <- paste("Confidence (Not likely to walk on desire path):", round(confidence * 100, 2), "%")
      }
      
      # Convert prediction to desired format
      prediction_text <- ifelse(prediction == 1, "Likely to walk on desire path", "Not likely to walk on desire path")
      
      output$predictionText <- renderText(paste("Prediction:", prediction_text))
      output$confidenceText <- renderText(confidence_text)
    } else {
      output$predictionText <- renderText("Model not trained yet.")
      output$confidenceText <- renderText("")
    }
  })
}

# Run the application
shinyApp(ui = ui, server = server)
